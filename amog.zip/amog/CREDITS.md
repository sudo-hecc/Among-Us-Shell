# CREDITS
**People whose material shall been shown here in the credits.**
- The `themetune.mp3` was found on [voicemod](https://tuna.voicemod.net/sound/24225899-3086-47e3-a873-1464e84586cf) and was uploaded by [MajorBassReverb9476](https://tuna.voicemod.net/user/majorbassreverb9476).
